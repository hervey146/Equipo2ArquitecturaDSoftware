package formularios;

import graphics.BtnCuadro;
import graphics.BtnLinea;
import java.awt.Color;
import java.util.List;
import javax.swing.JPanel;
import model.Configuracion;
import model.Juego;
import model.Jugador;
import model.Linea;
import model.Marcador;

public class SalaJuego extends javax.swing.JDialog {


    private Jugador jugadorThis;
    
    

    public SalaJuego(javax.swing.JDialog parent, boolean modal, Jugador jugador) {
        super(parent, modal);
        
        initComponents();
        this.jugadorThis = jugador;

//        jugadores = new ArrayList<>(); // de alguna manera se obtendrán los registrados ya por la red, sabe cómo
//        marcador.addJugador(jugador);
//        jugadores.add(jugador);
        //otro jugador de prueba
//        Jugador foo = Jugador.getInstance("Pepito", 'p');
//        foo.setColor(Color.red);
//        foo.setAvatar(new BufferedImage(100, 100, BufferedImage.TYPE_BYTE_BINARY));
//        jugadores.add(foo);
//        marcador.addJugador(jugador);
//        Solo para PRUEBAS! DEBE RETIRARSE
    }

//    public void nuevoJugador(Jugador jugador) {
//        marcador.addJugador(jugador);
////        jugadores.add(jugador);
//        if (marcador.getJugadores().size() >= 4) {
//            iniciarPartida();
//        }
//    }

//    public void iniciarPartida() {
//        //se crea el lienzo según la cantidad de jugadores
//        //se va a llamar desde el botón
////        playerCount = marcador.getJugadores().size();
//        playerCount = 1;
//        gridSize = 5 * playerCount * playerCount - 15 * playerCount + 20;
//        lineasH = new Linea[gridSize + 1][gridSize + 1];
//        lineasV = new Linea[gridSize + 1][gridSize + 1];
//        grid = new BtnCuadro[gridSize][gridSize];
//        btnLineasH = new BtnLinea[gridSize + 1][gridSize + 1];
//        btnLineasV = new BtnLinea[gridSize + 1][gridSize + 1];
//        inicializaLineasH();
//        inicializaLineasV();
//        inicializaGrid();
////        juego = new Juego(marcador, lineasH, lineasV);
        
//        this.nomPlayer1.setText(jugadores.get(0).getNombre());
//        this.nomPlayer1.setForeground(jugadores.get(0).getColor());
//        this.nomPlayer2.setText(jugadores.get(1).getNombre());
//        this.nomPlayer2.setForeground(jugadores.get(0).getColor());
//        this.nomPlayer3.setText(jugadores.get(2).getNombre());
//        this.nomPlayer3.setForeground(jugadores.get(0).getColor());
//        this.nomPlayer4.setText(jugadores.get(3).getNombre());
//        this.nomPlayer4.setForeground(jugadores.get(0).getColor());
//
//        // se asigna el turno según su posición en la lista
//        turno = jugadores.indexOf(jugadorThis);
//        this.msgsLabel.setText("TU TURNO ES: " + (turno+1));
//        
//    }

//    //se llama cuando se abandona el juego
//    public void abandonaJugador(Jugador jugador, int turnoAbandono) {
//        marcador.eliminaJugador(jugador);
////        jugadores.remove(jugador);
//        if (marcador.getJugadores().size() < 2) {
//            terminarJuego();
//        }
//        /*
//         Aquí se hará todo lo necesario para borrar las lineas y cuadros del 
//         jugador que abandonó.
//         */
//        // si el turno de este es mayor al que abandonó
//        // entonces se recorre
//        if (turno > turnoAbandono) {
//            turno--;
//        }
//        this.msgsLabel.setText("El jugador " + jugador.getNombre() + " abandonó la partida.\nTU TURNO ES: " + (turno+1));
//        jugadores.remove(jugador);
//
//    }

    
//    // se llama cuando un jugador pinta linea
//    public void actualizarDatosMarcador() {
//        Map<Jugador, Integer> jugadores = marcador.getJugadores();
//        Map<Jugador, Integer> jugadoresCopy = jugadores;
//        List<Jugador> jugadoresList = juego.getJugadores();
//        Jugador[] players = marcador.getJugadores().keySet().toArray(new Jugador[jugadores.size()]);
//        Integer[] puntos = marcador.getJugadores().values().toArray(new Integer[jugadores.size()]);
//        for (int i = 0; i < jugadoresList.size(); i++) {
//            if (jugadorThis.equals(jugadoresList.get(i))) {
//                jugadores.clear();
//                jugadores.put(players[i], puntos[i]);
//                jugadoresCopy.remove(players[i], puntos[i]);
//                jugadores.putAll(jugadoresCopy);
//            }
//        }
//        players = marcador.getJugadores().keySet().toArray(new Jugador[jugadores.size()]);
//        puntos = marcador.getJugadores().values().toArray(new Integer[jugadores.size()]);
//        marcador.setJugadores(jugadores);
//        nomPlayer1.setText(players[0].getNombre());
//        iniPlayer1.setText(players[0].getLetra() + "");
//        puntosPlayer1.setText(puntos[0] + "");
//        nomPlayer2.setText(players[1].getNombre());
//        iniPlayer2.setText(players[1].getLetra() + "");
//        puntosPlayer2.setText(puntos[1] + "");
//        nomPlayer3.setText(players[2].getNombre());
//        iniPlayer3.setText(players[2].getLetra() + "");
//        puntosPlayer3.setText(puntos[2] + "");
//        nomPlayer4.setText(players[3].getNombre());
//        iniPlayer4.setText(players[3].getLetra() + "");
//        puntosPlayer4.setText(puntos[3] + "");
//    }
//
//    public void setTurnoRotando(int turno) {
//        this.turnoRotando = turno;
//        if(turnoRotando != turno) {
//            this.turnoLabel.setText("Esperando a " + this.jugadores.get(turno).getNombre());
//            this.btnAbandonar.setEnabled(false);
//            this.panelJuego.setEnabled(false);
//        } else {
//            this.turnoLabel.setText("Es tu turno!");
//            this.btnAbandonar.setEnabled(true);
//            this.panelJuego.setEnabled(true);
//        }
//    }
//    
//    public void setJugadores(List<Jugador> jugadores){
//        this.jugadores = jugadores;
//    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelJuego = new javax.swing.JPanel();
        btnCuadro00 = new javax.swing.JButton();
        btnCuadro01 = new javax.swing.JButton();
        btnCuadro02 = new javax.swing.JButton();
        btnCuadro03 = new javax.swing.JButton();
        btnCuadro04 = new javax.swing.JButton();
        btnCuadro05 = new javax.swing.JButton();
        btnCuadro06 = new javax.swing.JButton();
        btnCuadro07 = new javax.swing.JButton();
        btnCuadro08 = new javax.swing.JButton();
        btnCuadro09 = new javax.swing.JButton();
        lineaH00 = new javax.swing.JButton();
        lineaV00 = new javax.swing.JButton();
        lineaV01 = new javax.swing.JButton();
        lineaV02 = new javax.swing.JButton();
        lineaV03 = new javax.swing.JButton();
        lineaV04 = new javax.swing.JButton();
        lineaV05 = new javax.swing.JButton();
        lineaV06 = new javax.swing.JButton();
        lineaV07 = new javax.swing.JButton();
        lineaV08 = new javax.swing.JButton();
        lineaV09 = new javax.swing.JButton();
        lineaV010 = new javax.swing.JButton();
        lineaH01 = new javax.swing.JButton();
        lineaH02 = new javax.swing.JButton();
        lineaH03 = new javax.swing.JButton();
        lineaH04 = new javax.swing.JButton();
        lineaH05 = new javax.swing.JButton();
        lineaH06 = new javax.swing.JButton();
        lineaH07 = new javax.swing.JButton();
        lineaH08 = new javax.swing.JButton();
        lineaH09 = new javax.swing.JButton();
        lineaV10 = new javax.swing.JButton();
        btnCuadro10 = new javax.swing.JButton();
        lineaH10 = new javax.swing.JButton();
        lineaV11 = new javax.swing.JButton();
        btnCuadro11 = new javax.swing.JButton();
        lineaH11 = new javax.swing.JButton();
        lineaV12 = new javax.swing.JButton();
        btnCuadro12 = new javax.swing.JButton();
        lineaH12 = new javax.swing.JButton();
        lineaV13 = new javax.swing.JButton();
        btnCuadro13 = new javax.swing.JButton();
        lineaH13 = new javax.swing.JButton();
        lineaV14 = new javax.swing.JButton();
        btnCuadro14 = new javax.swing.JButton();
        lineaH14 = new javax.swing.JButton();
        lineaV15 = new javax.swing.JButton();
        btnCuadro15 = new javax.swing.JButton();
        lineaH15 = new javax.swing.JButton();
        lineaV16 = new javax.swing.JButton();
        btnCuadro16 = new javax.swing.JButton();
        lineaH16 = new javax.swing.JButton();
        lineaV17 = new javax.swing.JButton();
        btnCuadro17 = new javax.swing.JButton();
        lineaH17 = new javax.swing.JButton();
        lineaV18 = new javax.swing.JButton();
        btnCuadro18 = new javax.swing.JButton();
        lineaH18 = new javax.swing.JButton();
        lineaV19 = new javax.swing.JButton();
        btnCuadro19 = new javax.swing.JButton();
        lineaH19 = new javax.swing.JButton();
        lineaV110 = new javax.swing.JButton();
        lineaV20 = new javax.swing.JButton();
        btnCuadro20 = new javax.swing.JButton();
        lineaH20 = new javax.swing.JButton();
        lineaV21 = new javax.swing.JButton();
        btnCuadro21 = new javax.swing.JButton();
        lineaH21 = new javax.swing.JButton();
        lineaV22 = new javax.swing.JButton();
        btnCuadro22 = new javax.swing.JButton();
        lineaH22 = new javax.swing.JButton();
        lineaV23 = new javax.swing.JButton();
        btnCuadro23 = new javax.swing.JButton();
        lineaH23 = new javax.swing.JButton();
        lineaV24 = new javax.swing.JButton();
        btnCuadro24 = new javax.swing.JButton();
        lineaH24 = new javax.swing.JButton();
        lineaV25 = new javax.swing.JButton();
        btnCuadro25 = new javax.swing.JButton();
        lineaH25 = new javax.swing.JButton();
        lineaV26 = new javax.swing.JButton();
        btnCuadro26 = new javax.swing.JButton();
        lineaH26 = new javax.swing.JButton();
        lineaV27 = new javax.swing.JButton();
        btnCuadro27 = new javax.swing.JButton();
        lineaH27 = new javax.swing.JButton();
        lineaV28 = new javax.swing.JButton();
        btnCuadro28 = new javax.swing.JButton();
        lineaH28 = new javax.swing.JButton();
        lineaV29 = new javax.swing.JButton();
        btnCuadro29 = new javax.swing.JButton();
        lineaH29 = new javax.swing.JButton();
        lineaV210 = new javax.swing.JButton();
        lineaV30 = new javax.swing.JButton();
        btnCuadro30 = new javax.swing.JButton();
        lineaH30 = new javax.swing.JButton();
        lineaV31 = new javax.swing.JButton();
        btnCuadro31 = new javax.swing.JButton();
        lineaH31 = new javax.swing.JButton();
        lineaV32 = new javax.swing.JButton();
        btnCuadro32 = new javax.swing.JButton();
        lineaH32 = new javax.swing.JButton();
        lineaV33 = new javax.swing.JButton();
        btnCuadro33 = new javax.swing.JButton();
        lineaH33 = new javax.swing.JButton();
        lineaV34 = new javax.swing.JButton();
        btnCuadro34 = new javax.swing.JButton();
        lineaH34 = new javax.swing.JButton();
        lineaV35 = new javax.swing.JButton();
        btnCuadro35 = new javax.swing.JButton();
        lineaH35 = new javax.swing.JButton();
        lineaV36 = new javax.swing.JButton();
        btnCuadro36 = new javax.swing.JButton();
        lineaH36 = new javax.swing.JButton();
        lineaV37 = new javax.swing.JButton();
        btnCuadro37 = new javax.swing.JButton();
        lineaH37 = new javax.swing.JButton();
        lineaV38 = new javax.swing.JButton();
        btnCuadro38 = new javax.swing.JButton();
        lineaH38 = new javax.swing.JButton();
        lineaV39 = new javax.swing.JButton();
        btnCuadro39 = new javax.swing.JButton();
        lineaH39 = new javax.swing.JButton();
        lineaV310 = new javax.swing.JButton();
        lineaV40 = new javax.swing.JButton();
        btnCuadro40 = new javax.swing.JButton();
        lineaH40 = new javax.swing.JButton();
        lineaV41 = new javax.swing.JButton();
        btnCuadro41 = new javax.swing.JButton();
        lineaH41 = new javax.swing.JButton();
        lineaV42 = new javax.swing.JButton();
        btnCuadro42 = new javax.swing.JButton();
        lineaH42 = new javax.swing.JButton();
        lineaV43 = new javax.swing.JButton();
        btnCuadro43 = new javax.swing.JButton();
        lineaH43 = new javax.swing.JButton();
        lineaV44 = new javax.swing.JButton();
        btnCuadro44 = new javax.swing.JButton();
        lineaH44 = new javax.swing.JButton();
        lineaV45 = new javax.swing.JButton();
        btnCuadro45 = new javax.swing.JButton();
        lineaH45 = new javax.swing.JButton();
        lineaV46 = new javax.swing.JButton();
        btnCuadro46 = new javax.swing.JButton();
        lineaH46 = new javax.swing.JButton();
        lineaV47 = new javax.swing.JButton();
        btnCuadro47 = new javax.swing.JButton();
        lineaH47 = new javax.swing.JButton();
        lineaV48 = new javax.swing.JButton();
        btnCuadro48 = new javax.swing.JButton();
        lineaH48 = new javax.swing.JButton();
        lineaV49 = new javax.swing.JButton();
        btnCuadro49 = new javax.swing.JButton();
        lineaH49 = new javax.swing.JButton();
        lineaV410 = new javax.swing.JButton();
        lineaV50 = new javax.swing.JButton();
        btnCuadro50 = new javax.swing.JButton();
        lineaH50 = new javax.swing.JButton();
        lineaV51 = new javax.swing.JButton();
        btnCuadro51 = new javax.swing.JButton();
        lineaH51 = new javax.swing.JButton();
        lineaV52 = new javax.swing.JButton();
        btnCuadro52 = new javax.swing.JButton();
        lineaH52 = new javax.swing.JButton();
        lineaV53 = new javax.swing.JButton();
        btnCuadro53 = new javax.swing.JButton();
        lineaH53 = new javax.swing.JButton();
        lineaV54 = new javax.swing.JButton();
        btnCuadro54 = new javax.swing.JButton();
        lineaH54 = new javax.swing.JButton();
        lineaV55 = new javax.swing.JButton();
        btnCuadro55 = new javax.swing.JButton();
        lineaH55 = new javax.swing.JButton();
        lineaV56 = new javax.swing.JButton();
        btnCuadro56 = new javax.swing.JButton();
        lineaH56 = new javax.swing.JButton();
        lineaV57 = new javax.swing.JButton();
        btnCuadro57 = new javax.swing.JButton();
        lineaH57 = new javax.swing.JButton();
        lineaV58 = new javax.swing.JButton();
        btnCuadro58 = new javax.swing.JButton();
        lineaH58 = new javax.swing.JButton();
        lineaV59 = new javax.swing.JButton();
        btnCuadro59 = new javax.swing.JButton();
        lineaH59 = new javax.swing.JButton();
        lineaV510 = new javax.swing.JButton();
        lineaV60 = new javax.swing.JButton();
        btnCuadro60 = new javax.swing.JButton();
        lineaV61 = new javax.swing.JButton();
        btnCuadro61 = new javax.swing.JButton();
        lineaV62 = new javax.swing.JButton();
        btnCuadro62 = new javax.swing.JButton();
        lineaV63 = new javax.swing.JButton();
        btnCuadro63 = new javax.swing.JButton();
        lineaV64 = new javax.swing.JButton();
        btnCuadro64 = new javax.swing.JButton();
        lineaV65 = new javax.swing.JButton();
        btnCuadro65 = new javax.swing.JButton();
        lineaV66 = new javax.swing.JButton();
        btnCuadro66 = new javax.swing.JButton();
        lineaV67 = new javax.swing.JButton();
        btnCuadro67 = new javax.swing.JButton();
        lineaV68 = new javax.swing.JButton();
        btnCuadro68 = new javax.swing.JButton();
        lineaV69 = new javax.swing.JButton();
        btnCuadro69 = new javax.swing.JButton();
        lineaV610 = new javax.swing.JButton();
        lineaH69 = new javax.swing.JButton();
        lineaH68 = new javax.swing.JButton();
        lineaH67 = new javax.swing.JButton();
        lineaH66 = new javax.swing.JButton();
        lineaH65 = new javax.swing.JButton();
        lineaH64 = new javax.swing.JButton();
        lineaH63 = new javax.swing.JButton();
        lineaH62 = new javax.swing.JButton();
        lineaH60 = new javax.swing.JButton();
        lineaH61 = new javax.swing.JButton();
        lineaV70 = new javax.swing.JButton();
        btnCuadro70 = new javax.swing.JButton();
        lineaV71 = new javax.swing.JButton();
        btnCuadro71 = new javax.swing.JButton();
        lineaV72 = new javax.swing.JButton();
        btnCuadro72 = new javax.swing.JButton();
        lineaV73 = new javax.swing.JButton();
        btnCuadro73 = new javax.swing.JButton();
        lineaV74 = new javax.swing.JButton();
        btnCuadro74 = new javax.swing.JButton();
        lineaV75 = new javax.swing.JButton();
        btnCuadro75 = new javax.swing.JButton();
        lineaV76 = new javax.swing.JButton();
        btnCuadro76 = new javax.swing.JButton();
        lineaV77 = new javax.swing.JButton();
        btnCuadro77 = new javax.swing.JButton();
        lineaV78 = new javax.swing.JButton();
        btnCuadro78 = new javax.swing.JButton();
        lineaV79 = new javax.swing.JButton();
        btnCuadro79 = new javax.swing.JButton();
        lineaV710 = new javax.swing.JButton();
        lineaH79 = new javax.swing.JButton();
        lineaH78 = new javax.swing.JButton();
        lineaH77 = new javax.swing.JButton();
        lineaH76 = new javax.swing.JButton();
        lineaH75 = new javax.swing.JButton();
        lineaH74 = new javax.swing.JButton();
        lineaH73 = new javax.swing.JButton();
        lineaH72 = new javax.swing.JButton();
        lineaH70 = new javax.swing.JButton();
        lineaH71 = new javax.swing.JButton();
        lineaV80 = new javax.swing.JButton();
        btnCuadro80 = new javax.swing.JButton();
        lineaV81 = new javax.swing.JButton();
        btnCuadro81 = new javax.swing.JButton();
        lineaV82 = new javax.swing.JButton();
        btnCuadro82 = new javax.swing.JButton();
        lineaV83 = new javax.swing.JButton();
        btnCuadro83 = new javax.swing.JButton();
        lineaV84 = new javax.swing.JButton();
        btnCuadro84 = new javax.swing.JButton();
        lineaV85 = new javax.swing.JButton();
        btnCuadro85 = new javax.swing.JButton();
        lineaV86 = new javax.swing.JButton();
        btnCuadro86 = new javax.swing.JButton();
        lineaV87 = new javax.swing.JButton();
        btnCuadro87 = new javax.swing.JButton();
        lineaV88 = new javax.swing.JButton();
        btnCuadro88 = new javax.swing.JButton();
        lineaV89 = new javax.swing.JButton();
        btnCuadro89 = new javax.swing.JButton();
        lineaV810 = new javax.swing.JButton();
        lineaH89 = new javax.swing.JButton();
        lineaH88 = new javax.swing.JButton();
        lineaH87 = new javax.swing.JButton();
        lineaH86 = new javax.swing.JButton();
        lineaH85 = new javax.swing.JButton();
        lineaH84 = new javax.swing.JButton();
        lineaH83 = new javax.swing.JButton();
        lineaH82 = new javax.swing.JButton();
        lineaH80 = new javax.swing.JButton();
        lineaH81 = new javax.swing.JButton();
        lineaV90 = new javax.swing.JButton();
        btnCuadro90 = new javax.swing.JButton();
        lineaV91 = new javax.swing.JButton();
        btnCuadro91 = new javax.swing.JButton();
        lineaV92 = new javax.swing.JButton();
        btnCuadro92 = new javax.swing.JButton();
        lineaV93 = new javax.swing.JButton();
        btnCuadro93 = new javax.swing.JButton();
        lineaV94 = new javax.swing.JButton();
        btnCuadro94 = new javax.swing.JButton();
        lineaV95 = new javax.swing.JButton();
        btnCuadro95 = new javax.swing.JButton();
        lineaV96 = new javax.swing.JButton();
        btnCuadro96 = new javax.swing.JButton();
        lineaV97 = new javax.swing.JButton();
        btnCuadro97 = new javax.swing.JButton();
        lineaV98 = new javax.swing.JButton();
        btnCuadro98 = new javax.swing.JButton();
        lineaV99 = new javax.swing.JButton();
        btnCuadro99 = new javax.swing.JButton();
        lineaV910 = new javax.swing.JButton();
        lineaH99 = new javax.swing.JButton();
        lineaH98 = new javax.swing.JButton();
        lineaH97 = new javax.swing.JButton();
        lineaH96 = new javax.swing.JButton();
        lineaH95 = new javax.swing.JButton();
        lineaH94 = new javax.swing.JButton();
        lineaH93 = new javax.swing.JButton();
        lineaH92 = new javax.swing.JButton();
        lineaH90 = new javax.swing.JButton();
        lineaH91 = new javax.swing.JButton();
        lineaH100 = new javax.swing.JButton();
        lineaH101 = new javax.swing.JButton();
        lineaH102 = new javax.swing.JButton();
        lineaH103 = new javax.swing.JButton();
        lineaH104 = new javax.swing.JButton();
        lineaH105 = new javax.swing.JButton();
        lineaH106 = new javax.swing.JButton();
        lineaH107 = new javax.swing.JButton();
        lineaH108 = new javax.swing.JButton();
        lineaH109 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        imgPlayer1 = new javax.swing.JLabel();
        imgPlayer2 = new javax.swing.JLabel();
        imgPlayer3 = new javax.swing.JLabel();
        imgPlayer4 = new javax.swing.JLabel();
        nomPlayer1 = new javax.swing.JLabel();
        nomPlayer2 = new javax.swing.JLabel();
        nomPlayer3 = new javax.swing.JLabel();
        nomPlayer4 = new javax.swing.JLabel();
        iniPlayer1 = new javax.swing.JLabel();
        iniPlayer2 = new javax.swing.JLabel();
        iniPlayer3 = new javax.swing.JLabel();
        iniPlayer4 = new javax.swing.JLabel();
        puntosPlayer1 = new javax.swing.JLabel();
        puntosPlayer2 = new javax.swing.JLabel();
        puntosPlayer3 = new javax.swing.JLabel();
        puntosPlayer4 = new javax.swing.JLabel();
        BtnConfigColor = new javax.swing.JButton();
        btnAbandonar = new javax.swing.JButton();
        msgsLabel = new javax.swing.JLabel();
        turnoLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(new java.awt.Dimension(600, 400));

        panelJuego.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelJuego.setMaximumSize(new java.awt.Dimension(570, 570));
        panelJuego.setMinimumSize(new java.awt.Dimension(570, 570));
        panelJuego.setRequestFocusEnabled(false);

        lineaV00.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV01.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV02.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV03.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV04.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV05.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV06.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV07.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV08.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV09.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV010.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV10.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV11.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV12.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV13.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV14.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV15.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV16.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV17.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV18.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV19.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV110.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV20.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV21.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV22.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV23.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV24.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV25.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV26.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV27.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV28.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV29.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV210.setPreferredSize(new java.awt.Dimension(13, 16));
        lineaV210.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lineaV210ActionPerformed(evt);
            }
        });

        lineaV30.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV31.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV32.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV33.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV34.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV35.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV36.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV37.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV38.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV39.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV310.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV40.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV41.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV42.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV43.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV44.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV45.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV46.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV47.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV48.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV49.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV410.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV50.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV51.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV52.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV53.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV54.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV55.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV56.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV57.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV58.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV59.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV510.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV60.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV61.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV62.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV63.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV64.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV65.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV66.setPreferredSize(new java.awt.Dimension(13, 16));

        btnCuadro66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuadro66ActionPerformed(evt);
            }
        });

        lineaV67.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV68.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV69.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV610.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV70.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV71.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV72.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV73.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV74.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV75.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV76.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV77.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV78.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV79.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV710.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV80.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV81.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV82.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV83.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV84.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV85.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV86.setPreferredSize(new java.awt.Dimension(13, 16));
        lineaV86.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lineaV86ActionPerformed(evt);
            }
        });

        lineaV87.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV88.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV89.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV810.setPreferredSize(new java.awt.Dimension(13, 16));
        lineaV810.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lineaV810ActionPerformed(evt);
            }
        });

        lineaV90.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV91.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV92.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV93.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV94.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV95.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV96.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV97.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV98.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV99.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaV910.setPreferredSize(new java.awt.Dimension(13, 16));

        lineaH92.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lineaH92ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelJuegoLayout = new javax.swing.GroupLayout(panelJuego);
        panelJuego.setLayout(panelJuegoLayout);
        panelJuegoLayout.setHorizontalGroup(
            panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelJuegoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelJuegoLayout.createSequentialGroup()
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV60, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH60)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro60)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV61, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro61)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV62, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro62))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH61)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH62)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV63, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro63))
                                    .addComponent(lineaH63))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV64, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro64))
                                    .addComponent(lineaH64))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV65, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro65)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV66, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro66))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH65)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH66)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV67, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro67))
                                    .addComponent(lineaH67))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV68, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro68))
                                    .addComponent(lineaH68))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lineaH69)
                                    .addComponent(lineaH79)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV69, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro69)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV610, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV40, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH40)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro40)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV41, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro41)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV42, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro42))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH41)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH42)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV43, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro43))
                                    .addComponent(lineaH43))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV44, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro44))
                                    .addComponent(lineaH44))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV45, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro45)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV46, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro46))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH45)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH46)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV47, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro47))
                                    .addComponent(lineaH47))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV48, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro48))
                                    .addComponent(lineaH48))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV49, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro49))
                                    .addComponent(lineaH49))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV410, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV50, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH50)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro50)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV51, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro51)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV52, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro52))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH51)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH52)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV53, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro53))
                                    .addComponent(lineaH53))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV54, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro54))
                                    .addComponent(lineaH54))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV55, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro55)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV56, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro56))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH55)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH56)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV57, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro57))
                                    .addComponent(lineaH57))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV58, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro58))
                                    .addComponent(lineaH58))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV59, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro59)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(lineaH59, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV510, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(lineaH19))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV00, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaH00)
                                                .addGap(3, 3, 3))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                                .addComponent(btnCuadro00)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addComponent(lineaV01, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(btnCuadro01)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lineaV02, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnCuadro02))
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaH01)
                                                .addGap(25, 25, 25)
                                                .addComponent(lineaH02)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaV03, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnCuadro03))
                                            .addComponent(lineaH03))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaV04, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnCuadro04))
                                            .addComponent(lineaH04))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV05, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(btnCuadro05)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lineaV06, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(2, 2, 2)
                                                .addComponent(btnCuadro06))
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaH05)
                                                .addGap(21, 21, 21)
                                                .addComponent(lineaH06)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaV07, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnCuadro07))
                                            .addComponent(lineaH07))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaV08, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(2, 2, 2)
                                                .addComponent(btnCuadro08))
                                            .addComponent(lineaH08))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaV09, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnCuadro09)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                            .addComponent(lineaH09, javax.swing.GroupLayout.Alignment.TRAILING))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV010, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(6, 6, 6))
                    .addGroup(panelJuegoLayout.createSequentialGroup()
                        .addComponent(lineaV80, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaH80)
                                .addGap(3, 3, 3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                .addComponent(btnCuadro80)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addComponent(lineaV81, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(btnCuadro81)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV82, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro82))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaH81)
                                .addGap(25, 25, 25)
                                .addComponent(lineaH82)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV83, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro83))
                            .addComponent(lineaH83))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV84, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro84))
                            .addComponent(lineaH84))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lineaV85, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(btnCuadro85)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV86, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(btnCuadro86))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaH85)
                                .addGap(21, 21, 21)
                                .addComponent(lineaH86)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV87, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro87))
                            .addComponent(lineaH87))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV88, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(btnCuadro88))
                            .addComponent(lineaH88))
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV89, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro99)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV910, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro89)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV810, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lineaH99)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(lineaH89)
                                .addGap(25, 25, 25))))
                    .addGroup(panelJuegoLayout.createSequentialGroup()
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV90, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaH90)
                                                .addGap(3, 3, 3))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                                .addComponent(btnCuadro90)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addComponent(lineaV91, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lineaH100))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(panelJuegoLayout.createSequentialGroup()
                                            .addComponent(btnCuadro91)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(lineaV92, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnCuadro92))
                                        .addGroup(panelJuegoLayout.createSequentialGroup()
                                            .addComponent(lineaH91)
                                            .addGap(25, 25, 25)
                                            .addComponent(lineaH92)))
                                    .addComponent(lineaH101)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addGap(55, 55, 55)
                                        .addComponent(lineaH102)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV93, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro93))
                                    .addComponent(lineaH93)
                                    .addComponent(lineaH103))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV94, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btnCuadro94)
                                            .addComponent(lineaH94))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV95, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaH95)
                                                .addGap(21, 21, 21)
                                                .addComponent(lineaH96))
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(lineaH105)
                                                    .addComponent(btnCuadro95))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                                        .addComponent(lineaV96, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(2, 2, 2)
                                                        .addComponent(btnCuadro96))
                                                    .addComponent(lineaH106)))))
                                    .addComponent(lineaH104))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV97, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro97))
                                    .addComponent(lineaH97)
                                    .addComponent(lineaH107))
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV98, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(btnCuadro98)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lineaV99, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                                .addComponent(lineaH108)
                                                .addGap(21, 21, 21)
                                                .addComponent(lineaH109))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lineaH98)
                                        .addGap(55, 55, 55))))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV70, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH70)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro70)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV71, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro71)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV72, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro72))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH71)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH72)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV73, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro73))
                                    .addComponent(lineaH73))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV74, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro74))
                                    .addComponent(lineaH74))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV75, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro75)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV76, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro76))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH75)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH76)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV77, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro77))
                                    .addComponent(lineaH77))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV78, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro78))
                                    .addComponent(lineaH78))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV79, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro79)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV710, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV30, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH30)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro30)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV31, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro31)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV32, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro32))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH31)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH32)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV33, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro33))
                                    .addComponent(lineaH33))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV34, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro34))
                                    .addComponent(lineaH34))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV35, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro35)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV36, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro36))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH35)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH36)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV37, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro37))
                                    .addComponent(lineaH37))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV38, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro38))
                                    .addComponent(lineaH38))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV39, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro39)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV310, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV10, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH10)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV11, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV12, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro12))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH11)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH12)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV13, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro13))
                                    .addComponent(lineaH13))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV14, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro14))
                                    .addComponent(lineaH14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV15, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro15)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV16, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro16))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH15)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH16)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV17, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro17))
                                    .addComponent(lineaH17))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV18, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro18))
                                    .addComponent(lineaH18))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV19, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCuadro19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV110, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelJuegoLayout.createSequentialGroup()
                                .addComponent(lineaV20, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH20)
                                        .addGap(3, 3, 3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(lineaV21, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro21)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV22, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro22))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH21)
                                        .addGap(25, 25, 25)
                                        .addComponent(lineaH22)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV23, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro23))
                                    .addComponent(lineaH23))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV24, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro24))
                                    .addComponent(lineaH24))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV25, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(btnCuadro25)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lineaV26, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro26))
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaH25)
                                        .addGap(21, 21, 21)
                                        .addComponent(lineaH26)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV27, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro27))
                                    .addComponent(lineaH27))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV28, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(2, 2, 2)
                                        .addComponent(btnCuadro28))
                                    .addComponent(lineaH28))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(panelJuegoLayout.createSequentialGroup()
                                        .addComponent(lineaV29, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCuadro29))
                                    .addComponent(lineaH29)
                                    .addComponent(lineaH39))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lineaV210, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())))
        );
        panelJuegoLayout.setVerticalGroup(
            panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelJuegoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH00, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH01, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH02, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH03, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH04, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH05, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH06, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH07, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH08, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH09, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro09, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(btnCuadro08, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro07, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro06, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro05, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro04, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro03, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro02, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro01, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro00, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV00, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV01, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV02, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV03, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV04, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV05, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV06, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV07, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV08, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV09, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV010, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH10, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH11, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH12, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH13, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH14, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH15, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH16, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH17, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH18, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH19, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV110, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH20, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH21, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH22, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH23, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH24, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH25, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH26, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH27, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH28, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH29, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro29, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro28, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro27, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro25, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro24, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV24, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV28, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV210, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH30, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH31, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH32, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH33, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH34, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH35, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH36, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH37, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH38, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH39, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro39, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro38, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro37, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro36, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro35, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro34, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro33, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro32, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro31, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro30, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV34, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV36, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV38, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV310, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH40, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH41, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH42, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH43, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH44, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH45, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH46, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH47, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH48, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH49, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro49, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro48, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro47, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro46, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro45, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro44, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro43, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro42, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro41, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro40, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV42, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV44, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV46, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV48, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV49, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV410, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH50, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH51, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH52, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH53, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH54, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH55, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH56, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH57, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH58, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH59, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro59, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro58, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro57, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro56, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro55, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro54, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro53, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro52, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro51, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro50, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV50, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV52, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV53, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV54, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV55, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV56, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV57, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV58, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV59, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV510, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH60, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH61, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH62, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH63, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH64, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH65, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH66, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH67, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH68, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH69, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro69, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro68, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro67, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro66, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro65, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro64, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro63, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro62, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro61, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro60, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV60, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV62, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV63, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV64, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV66, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV67, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV68, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV69, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV610, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH70, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH71, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH72, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH73, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH74, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH75, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH76, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH77, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH78, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH79, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro79, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro78, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro77, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro76, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro75, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro74, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro73, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro72, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro71, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro70, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV70, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV71, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV72, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV73, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV74, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV75, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV76, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV77, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV78, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV79, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV710, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH80, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH81, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH82, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH83, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH84, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH85, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH86, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH87, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH88, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH89, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro89, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro88, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro87, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro86, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro85, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro84, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro83, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro82, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro81, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro80, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV80, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV81, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV82, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV83, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV84, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV85, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV86, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV87, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV88, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV89, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV810, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lineaH90, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH91, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH92, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH93, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH94, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH95, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH96, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH97, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH98, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lineaH99, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCuadro99, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro98, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro97, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro96, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro95, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro94, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro93, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro92, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro91, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadro90, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV90, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV91, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV92, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV93, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV94, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV95, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV96, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV97, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV98, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV99, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineaV910, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelJuegoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lineaH100, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lineaH101, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lineaH102, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lineaH104, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lineaH103, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lineaH105, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lineaH106, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelJuegoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelJuegoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lineaH107, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lineaH108, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lineaH109, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        imgPlayer1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        imgPlayer2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        imgPlayer3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        imgPlayer4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        nomPlayer1.setText("JUGADOR1");

        nomPlayer2.setText("JUGADOR2");

        nomPlayer3.setText("JUGADOR3");

        nomPlayer4.setText("JUGADOR4");

        iniPlayer1.setText("INI");

        iniPlayer2.setText("INI");

        iniPlayer3.setText("INI");

        iniPlayer4.setText("INI");

        puntosPlayer1.setText("0");

        puntosPlayer2.setText("0");

        puntosPlayer3.setText("0");

        puntosPlayer4.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator2)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(imgPlayer4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nomPlayer4)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(iniPlayer4)
                                        .addGap(18, 18, 18)
                                        .addComponent(puntosPlayer4))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(imgPlayer2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nomPlayer2)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(iniPlayer2)
                                        .addGap(18, 18, 18)
                                        .addComponent(puntosPlayer2))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(imgPlayer3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nomPlayer3)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(iniPlayer3)
                                        .addGap(18, 18, 18)
                                        .addComponent(puntosPlayer3))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(imgPlayer1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(iniPlayer1)
                                        .addGap(18, 18, 18)
                                        .addComponent(puntosPlayer1))
                                    .addComponent(nomPlayer1))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(imgPlayer1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(nomPlayer1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(iniPlayer1)
                            .addComponent(puntosPlayer1))))
                .addGap(8, 8, 8)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(imgPlayer2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(nomPlayer2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(iniPlayer2)
                            .addComponent(puntosPlayer2))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(imgPlayer3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(nomPlayer3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(iniPlayer3)
                            .addComponent(puntosPlayer3))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(imgPlayer4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(nomPlayer4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(iniPlayer4)
                            .addComponent(puntosPlayer4))))
                .addContainerGap())
        );

        BtnConfigColor.setText("Configurar Color");
        BtnConfigColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnConfigColorActionPerformed(evt);
            }
        });

        btnAbandonar.setText("Abandonar");
        btnAbandonar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbandonarActionPerformed(evt);
            }
        });

        msgsLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        msgsLabel.setForeground(new java.awt.Color(51, 204, 0));

        turnoLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        turnoLabel.setForeground(new java.awt.Color(51, 204, 0));
        turnoLabel.setText("Esperando a los demás jugadores");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(panelJuego, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BtnConfigColor, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                        .addComponent(btnAbandonar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(msgsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(turnoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(panelJuego, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(msgsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(turnoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtnConfigColor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnAbandonar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnConfigColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnConfigColorActionPerformed
        // TODO add your handling code here:
//        actualizarColoresMarcador();
    }//GEN-LAST:event_BtnConfigColorActionPerformed

    private void lineaV810ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lineaV810ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lineaV810ActionPerformed

    private void lineaV210ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lineaV210ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lineaV210ActionPerformed

    private void lineaH92ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lineaH92ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lineaH92ActionPerformed

    private void lineaV86ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lineaV86ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lineaV86ActionPerformed

    private void btnCuadro66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuadro66ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCuadro66ActionPerformed

    private void btnAbandonarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbandonarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAbandonarActionPerformed

    /**
     * el evento window listener se puede usar para el botón de abandonar
     * partida, cuando se presione la x.
     *
     * @param args
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalaJuego.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalaJuego.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalaJuego.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalaJuego.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SalaJuego dialog = new SalaJuego(new javax.swing.JDialog(), true, new Jugador("Pedro", 'a', Color.yellow, "src/img/imagen_dos.jpg", new Configuracion()));
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnConfigColor;
    private javax.swing.JButton btnAbandonar;
    private javax.swing.JButton btnCuadro00;
    private javax.swing.JButton btnCuadro01;
    private javax.swing.JButton btnCuadro02;
    private javax.swing.JButton btnCuadro03;
    private javax.swing.JButton btnCuadro04;
    private javax.swing.JButton btnCuadro05;
    private javax.swing.JButton btnCuadro06;
    private javax.swing.JButton btnCuadro07;
    private javax.swing.JButton btnCuadro08;
    private javax.swing.JButton btnCuadro09;
    private javax.swing.JButton btnCuadro10;
    private javax.swing.JButton btnCuadro11;
    private javax.swing.JButton btnCuadro12;
    private javax.swing.JButton btnCuadro13;
    private javax.swing.JButton btnCuadro14;
    private javax.swing.JButton btnCuadro15;
    private javax.swing.JButton btnCuadro16;
    private javax.swing.JButton btnCuadro17;
    private javax.swing.JButton btnCuadro18;
    private javax.swing.JButton btnCuadro19;
    private javax.swing.JButton btnCuadro20;
    private javax.swing.JButton btnCuadro21;
    private javax.swing.JButton btnCuadro22;
    private javax.swing.JButton btnCuadro23;
    private javax.swing.JButton btnCuadro24;
    private javax.swing.JButton btnCuadro25;
    private javax.swing.JButton btnCuadro26;
    private javax.swing.JButton btnCuadro27;
    private javax.swing.JButton btnCuadro28;
    private javax.swing.JButton btnCuadro29;
    private javax.swing.JButton btnCuadro30;
    private javax.swing.JButton btnCuadro31;
    private javax.swing.JButton btnCuadro32;
    private javax.swing.JButton btnCuadro33;
    private javax.swing.JButton btnCuadro34;
    private javax.swing.JButton btnCuadro35;
    private javax.swing.JButton btnCuadro36;
    private javax.swing.JButton btnCuadro37;
    private javax.swing.JButton btnCuadro38;
    private javax.swing.JButton btnCuadro39;
    private javax.swing.JButton btnCuadro40;
    private javax.swing.JButton btnCuadro41;
    private javax.swing.JButton btnCuadro42;
    private javax.swing.JButton btnCuadro43;
    private javax.swing.JButton btnCuadro44;
    private javax.swing.JButton btnCuadro45;
    private javax.swing.JButton btnCuadro46;
    private javax.swing.JButton btnCuadro47;
    private javax.swing.JButton btnCuadro48;
    private javax.swing.JButton btnCuadro49;
    private javax.swing.JButton btnCuadro50;
    private javax.swing.JButton btnCuadro51;
    private javax.swing.JButton btnCuadro52;
    private javax.swing.JButton btnCuadro53;
    private javax.swing.JButton btnCuadro54;
    private javax.swing.JButton btnCuadro55;
    private javax.swing.JButton btnCuadro56;
    private javax.swing.JButton btnCuadro57;
    private javax.swing.JButton btnCuadro58;
    private javax.swing.JButton btnCuadro59;
    private javax.swing.JButton btnCuadro60;
    private javax.swing.JButton btnCuadro61;
    private javax.swing.JButton btnCuadro62;
    private javax.swing.JButton btnCuadro63;
    private javax.swing.JButton btnCuadro64;
    private javax.swing.JButton btnCuadro65;
    private javax.swing.JButton btnCuadro66;
    private javax.swing.JButton btnCuadro67;
    private javax.swing.JButton btnCuadro68;
    private javax.swing.JButton btnCuadro69;
    private javax.swing.JButton btnCuadro70;
    private javax.swing.JButton btnCuadro71;
    private javax.swing.JButton btnCuadro72;
    private javax.swing.JButton btnCuadro73;
    private javax.swing.JButton btnCuadro74;
    private javax.swing.JButton btnCuadro75;
    private javax.swing.JButton btnCuadro76;
    private javax.swing.JButton btnCuadro77;
    private javax.swing.JButton btnCuadro78;
    private javax.swing.JButton btnCuadro79;
    private javax.swing.JButton btnCuadro80;
    private javax.swing.JButton btnCuadro81;
    private javax.swing.JButton btnCuadro82;
    private javax.swing.JButton btnCuadro83;
    private javax.swing.JButton btnCuadro84;
    private javax.swing.JButton btnCuadro85;
    private javax.swing.JButton btnCuadro86;
    private javax.swing.JButton btnCuadro87;
    private javax.swing.JButton btnCuadro88;
    private javax.swing.JButton btnCuadro89;
    private javax.swing.JButton btnCuadro90;
    private javax.swing.JButton btnCuadro91;
    private javax.swing.JButton btnCuadro92;
    private javax.swing.JButton btnCuadro93;
    private javax.swing.JButton btnCuadro94;
    private javax.swing.JButton btnCuadro95;
    private javax.swing.JButton btnCuadro96;
    private javax.swing.JButton btnCuadro97;
    private javax.swing.JButton btnCuadro98;
    private javax.swing.JButton btnCuadro99;
    private javax.swing.JLabel imgPlayer1;
    private javax.swing.JLabel imgPlayer2;
    private javax.swing.JLabel imgPlayer3;
    private javax.swing.JLabel imgPlayer4;
    private javax.swing.JLabel iniPlayer1;
    private javax.swing.JLabel iniPlayer2;
    private javax.swing.JLabel iniPlayer3;
    private javax.swing.JLabel iniPlayer4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JButton lineaH00;
    private javax.swing.JButton lineaH01;
    private javax.swing.JButton lineaH02;
    private javax.swing.JButton lineaH03;
    private javax.swing.JButton lineaH04;
    private javax.swing.JButton lineaH05;
    private javax.swing.JButton lineaH06;
    private javax.swing.JButton lineaH07;
    private javax.swing.JButton lineaH08;
    private javax.swing.JButton lineaH09;
    private javax.swing.JButton lineaH10;
    private javax.swing.JButton lineaH100;
    private javax.swing.JButton lineaH101;
    private javax.swing.JButton lineaH102;
    private javax.swing.JButton lineaH103;
    private javax.swing.JButton lineaH104;
    private javax.swing.JButton lineaH105;
    private javax.swing.JButton lineaH106;
    private javax.swing.JButton lineaH107;
    private javax.swing.JButton lineaH108;
    private javax.swing.JButton lineaH109;
    private javax.swing.JButton lineaH11;
    private javax.swing.JButton lineaH12;
    private javax.swing.JButton lineaH13;
    private javax.swing.JButton lineaH14;
    private javax.swing.JButton lineaH15;
    private javax.swing.JButton lineaH16;
    private javax.swing.JButton lineaH17;
    private javax.swing.JButton lineaH18;
    private javax.swing.JButton lineaH19;
    private javax.swing.JButton lineaH20;
    private javax.swing.JButton lineaH21;
    private javax.swing.JButton lineaH22;
    private javax.swing.JButton lineaH23;
    private javax.swing.JButton lineaH24;
    private javax.swing.JButton lineaH25;
    private javax.swing.JButton lineaH26;
    private javax.swing.JButton lineaH27;
    private javax.swing.JButton lineaH28;
    private javax.swing.JButton lineaH29;
    private javax.swing.JButton lineaH30;
    private javax.swing.JButton lineaH31;
    private javax.swing.JButton lineaH32;
    private javax.swing.JButton lineaH33;
    private javax.swing.JButton lineaH34;
    private javax.swing.JButton lineaH35;
    private javax.swing.JButton lineaH36;
    private javax.swing.JButton lineaH37;
    private javax.swing.JButton lineaH38;
    private javax.swing.JButton lineaH39;
    private javax.swing.JButton lineaH40;
    private javax.swing.JButton lineaH41;
    private javax.swing.JButton lineaH42;
    private javax.swing.JButton lineaH43;
    private javax.swing.JButton lineaH44;
    private javax.swing.JButton lineaH45;
    private javax.swing.JButton lineaH46;
    private javax.swing.JButton lineaH47;
    private javax.swing.JButton lineaH48;
    private javax.swing.JButton lineaH49;
    private javax.swing.JButton lineaH50;
    private javax.swing.JButton lineaH51;
    private javax.swing.JButton lineaH52;
    private javax.swing.JButton lineaH53;
    private javax.swing.JButton lineaH54;
    private javax.swing.JButton lineaH55;
    private javax.swing.JButton lineaH56;
    private javax.swing.JButton lineaH57;
    private javax.swing.JButton lineaH58;
    private javax.swing.JButton lineaH59;
    private javax.swing.JButton lineaH60;
    private javax.swing.JButton lineaH61;
    private javax.swing.JButton lineaH62;
    private javax.swing.JButton lineaH63;
    private javax.swing.JButton lineaH64;
    private javax.swing.JButton lineaH65;
    private javax.swing.JButton lineaH66;
    private javax.swing.JButton lineaH67;
    private javax.swing.JButton lineaH68;
    private javax.swing.JButton lineaH69;
    private javax.swing.JButton lineaH70;
    private javax.swing.JButton lineaH71;
    private javax.swing.JButton lineaH72;
    private javax.swing.JButton lineaH73;
    private javax.swing.JButton lineaH74;
    private javax.swing.JButton lineaH75;
    private javax.swing.JButton lineaH76;
    private javax.swing.JButton lineaH77;
    private javax.swing.JButton lineaH78;
    private javax.swing.JButton lineaH79;
    private javax.swing.JButton lineaH80;
    private javax.swing.JButton lineaH81;
    private javax.swing.JButton lineaH82;
    private javax.swing.JButton lineaH83;
    private javax.swing.JButton lineaH84;
    private javax.swing.JButton lineaH85;
    private javax.swing.JButton lineaH86;
    private javax.swing.JButton lineaH87;
    private javax.swing.JButton lineaH88;
    private javax.swing.JButton lineaH89;
    private javax.swing.JButton lineaH90;
    private javax.swing.JButton lineaH91;
    private javax.swing.JButton lineaH92;
    private javax.swing.JButton lineaH93;
    private javax.swing.JButton lineaH94;
    private javax.swing.JButton lineaH95;
    private javax.swing.JButton lineaH96;
    private javax.swing.JButton lineaH97;
    private javax.swing.JButton lineaH98;
    private javax.swing.JButton lineaH99;
    private javax.swing.JButton lineaV00;
    private javax.swing.JButton lineaV01;
    private javax.swing.JButton lineaV010;
    private javax.swing.JButton lineaV02;
    private javax.swing.JButton lineaV03;
    private javax.swing.JButton lineaV04;
    private javax.swing.JButton lineaV05;
    private javax.swing.JButton lineaV06;
    private javax.swing.JButton lineaV07;
    private javax.swing.JButton lineaV08;
    private javax.swing.JButton lineaV09;
    private javax.swing.JButton lineaV10;
    private javax.swing.JButton lineaV11;
    private javax.swing.JButton lineaV110;
    private javax.swing.JButton lineaV12;
    private javax.swing.JButton lineaV13;
    private javax.swing.JButton lineaV14;
    private javax.swing.JButton lineaV15;
    private javax.swing.JButton lineaV16;
    private javax.swing.JButton lineaV17;
    private javax.swing.JButton lineaV18;
    private javax.swing.JButton lineaV19;
    private javax.swing.JButton lineaV20;
    private javax.swing.JButton lineaV21;
    private javax.swing.JButton lineaV210;
    private javax.swing.JButton lineaV22;
    private javax.swing.JButton lineaV23;
    private javax.swing.JButton lineaV24;
    private javax.swing.JButton lineaV25;
    private javax.swing.JButton lineaV26;
    private javax.swing.JButton lineaV27;
    private javax.swing.JButton lineaV28;
    private javax.swing.JButton lineaV29;
    private javax.swing.JButton lineaV30;
    private javax.swing.JButton lineaV31;
    private javax.swing.JButton lineaV310;
    private javax.swing.JButton lineaV32;
    private javax.swing.JButton lineaV33;
    private javax.swing.JButton lineaV34;
    private javax.swing.JButton lineaV35;
    private javax.swing.JButton lineaV36;
    private javax.swing.JButton lineaV37;
    private javax.swing.JButton lineaV38;
    private javax.swing.JButton lineaV39;
    private javax.swing.JButton lineaV40;
    private javax.swing.JButton lineaV41;
    private javax.swing.JButton lineaV410;
    private javax.swing.JButton lineaV42;
    private javax.swing.JButton lineaV43;
    private javax.swing.JButton lineaV44;
    private javax.swing.JButton lineaV45;
    private javax.swing.JButton lineaV46;
    private javax.swing.JButton lineaV47;
    private javax.swing.JButton lineaV48;
    private javax.swing.JButton lineaV49;
    private javax.swing.JButton lineaV50;
    private javax.swing.JButton lineaV51;
    private javax.swing.JButton lineaV510;
    private javax.swing.JButton lineaV52;
    private javax.swing.JButton lineaV53;
    private javax.swing.JButton lineaV54;
    private javax.swing.JButton lineaV55;
    private javax.swing.JButton lineaV56;
    private javax.swing.JButton lineaV57;
    private javax.swing.JButton lineaV58;
    private javax.swing.JButton lineaV59;
    private javax.swing.JButton lineaV60;
    private javax.swing.JButton lineaV61;
    private javax.swing.JButton lineaV610;
    private javax.swing.JButton lineaV62;
    private javax.swing.JButton lineaV63;
    private javax.swing.JButton lineaV64;
    private javax.swing.JButton lineaV65;
    private javax.swing.JButton lineaV66;
    private javax.swing.JButton lineaV67;
    private javax.swing.JButton lineaV68;
    private javax.swing.JButton lineaV69;
    private javax.swing.JButton lineaV70;
    private javax.swing.JButton lineaV71;
    private javax.swing.JButton lineaV710;
    private javax.swing.JButton lineaV72;
    private javax.swing.JButton lineaV73;
    private javax.swing.JButton lineaV74;
    private javax.swing.JButton lineaV75;
    private javax.swing.JButton lineaV76;
    private javax.swing.JButton lineaV77;
    private javax.swing.JButton lineaV78;
    private javax.swing.JButton lineaV79;
    private javax.swing.JButton lineaV80;
    private javax.swing.JButton lineaV81;
    private javax.swing.JButton lineaV810;
    private javax.swing.JButton lineaV82;
    private javax.swing.JButton lineaV83;
    private javax.swing.JButton lineaV84;
    private javax.swing.JButton lineaV85;
    private javax.swing.JButton lineaV86;
    private javax.swing.JButton lineaV87;
    private javax.swing.JButton lineaV88;
    private javax.swing.JButton lineaV89;
    private javax.swing.JButton lineaV90;
    private javax.swing.JButton lineaV91;
    private javax.swing.JButton lineaV910;
    private javax.swing.JButton lineaV92;
    private javax.swing.JButton lineaV93;
    private javax.swing.JButton lineaV94;
    private javax.swing.JButton lineaV95;
    private javax.swing.JButton lineaV96;
    private javax.swing.JButton lineaV97;
    private javax.swing.JButton lineaV98;
    private javax.swing.JButton lineaV99;
    private javax.swing.JLabel msgsLabel;
    private javax.swing.JLabel nomPlayer1;
    private javax.swing.JLabel nomPlayer2;
    private javax.swing.JLabel nomPlayer3;
    private javax.swing.JLabel nomPlayer4;
    private javax.swing.JPanel panelJuego;
    private javax.swing.JLabel puntosPlayer1;
    private javax.swing.JLabel puntosPlayer2;
    private javax.swing.JLabel puntosPlayer3;
    private javax.swing.JLabel puntosPlayer4;
    private javax.swing.JLabel turnoLabel;
    // End of variables declaration//GEN-END:variables
}
