package conexion;

import eventos.AbandonoEvent;
import model.Jugador;
import eventos.Evento;
import eventos.InicioPartidaEvent;
import eventos.JugadorRepetidoEvent;
import eventos.PintaLineaEvent;
import eventos.SalaLlenaEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import model.Linea;
import formularios.FrmSalaJuego;

public class Servidor implements Runnable {

    final int ServerPort = 8080;
    private Jugador jugadorThis; // jugador de este cliente
    private List<Jugador> jugadores; // lista de todos los jugadores, se crea en el hilo.
    private int turnoRotando; // turno del jugador con el que va actualmente 
    private int turno; // turno correspondiente a este cliente
    private Thread hiloSocket;
    private PintaLineaEvent plevent;
    
    
    public Servidor (Jugador jugador) {
        this.jugadorThis = jugador;
    }
    
    public void setPlevent(PintaLineaEvent plevent){
        this.plevent = plevent;
    }
    
    public List<Jugador> getJugadores() {
        return jugadores;
    }
    
    public int getTurno(){
        return turno;
    }
    
    public synchronized void continuarHilo(){
        System.out.println("Before notify");
        notify();
        System.out.println("after notify");
    }
    
    @Override
    public void run() {

        InetAddress ip;
        try {
            ip = InetAddress.getByName("localhost");
            Socket s = new Socket(ip, ServerPort);

            // se obtienen los streams del socket
            ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
            oos.flush();

            // se envía al jugador
            oos.writeObject(jugadorThis);

            System.out.println("Esperando a que el juego inicie");

            Evento e = (Evento) ois.readObject();

            InicioPartidaEvent ipe = null;

            // se busca qué tipo de evento se recibe
            if (e instanceof InicioPartidaEvent) {
                ipe = (InicioPartidaEvent) e;
            } else if (e instanceof SalaLlenaEvent) {
                System.out.println("La sala está llena!");
                System.exit(0);
            } else if (e instanceof JugadorRepetidoEvent) {
                System.out.println("El caracter ya ha sido usado! ");
                System.exit(0);
            } else {
                // default
                System.out.println("Error de eventos!");
                System.exit(0);
            }

            System.out.println("EMPIEZA EL TIMBIRICHEE\nJugadores conectados:");
            
            jugadores = ipe.getJugadores();

            // se imprimen los jugadores
            jugadores.forEach(System.out::println);

            // se asigna el turno según su posición en la lista
            turno = jugadores.indexOf(jugadorThis);

            System.out.println("TU TURNO ES: " + turno);
            turnoRotando = 0;
            FrmSalaJuego.iniciarPartida();
            // ciclo principal del juego en sí
            while (true) {
                boolean abandono = false;
                // ciclo para escuchar los movimientos de los otros mientras no sea el turno de este cliente
                while (turnoRotando != turno) {
                    System.out.println("Esperando al jugador con el turno " + turnoRotando);

                    // se queda parada la ejecución de este hilo hasta que 
                    // el jugador en turno haga su movimiento
                    Evento eventoRecibido = (Evento) ois.readObject();

                    // si se pintó la línea
                    if (eventoRecibido instanceof PintaLineaEvent) {
                        // guardamos el evento
                        PintaLineaEvent ple = (PintaLineaEvent) eventoRecibido;
                        // obtenemos la línea que fue pintada por el jugador
                        Linea lineaPintada = ple.getLinea();
                        
                        /*
                            sout para pruebas, en esta sección se debe poner el 
                            código necesario para que la línea se pinte del jugador
                            en turno
                         */
                        
                        // se cambia el turno (0 -> 1 -> 2 -> 3 -> 0 -> 1) 
                        if(!ple.pintoCuadro()){
                            turnoRotando = ++turnoRotando >= jugadores.size() ? 0 : turnoRotando;
                        }
                        FrmSalaJuego.pintaLinea(lineaPintada.getFila(), lineaPintada.getCol(), lineaPintada.getOrientacion());
                        // si alguien abandonó el juego
                    } else if (eventoRecibido instanceof AbandonoEvent) {
                        System.out.println("Se envió evento de abandono :(");
                        AbandonoEvent ae = (AbandonoEvent) eventoRecibido;
                        Jugador jugadorAbandono = ae.getJugador();
                        System.out.println("El jugador que abandonó es: " + jugadorAbandono.getNombre());
                        // turno del jugador que abandonó
                        int turnoAbandono = ae.getTurno();
                        System.out.println("Tenía el turno: " + turnoAbandono);
                        // se acomoda el turnoRotando debido al abandono
                        // si abandona uno de turno anterior, turnoRotando se mueve 1 para atrás
                        if (turnoAbandono < turnoRotando) {
                            turnoRotando--;
                            // si se abandona la última posición, y este era quien estaba en turno
                            // entonces se acomoda a 0.
                        } else if (turnoAbandono == turnoRotando && turnoRotando == jugadores.size() - 1) {
                            turnoRotando = 0;
                        }
                        System.out.println("Nuevo turno rotando: " + turnoRotando);
                        // si el turno de este es mayor al que abandonó
                        // entonces se recorre
                        if (turno > turnoAbandono) {
                            turno--;
                        }
                        System.out.println("Nuevo turno de este cliente: " + turno);

                        System.out.println("El jugador" + jugadorAbandono.getNombre() + " abandonó la partida.");
                        // se elimina de la lista
                        jugadores.remove(jugadorAbandono);

                        /**
                         * *************************************************
                         * Aquí se llama al método (o se incluye el código) para
                         * eliminar las líneas y cuadros correspondientes al
                         * jugador que abandonó.
                         * *************************************************
                         */
                        // variable para reinciar el ciclo superior
                        abandono = true;
                        break;
                    } else {
                        // default
                        System.out.println("ERROR DE EVENTOS");
                    }

                }
                if (abandono) {
                    continue;
                }
                
                Linea linea = new Linea(jugadorThis);
                linea.setJugador(jugadorThis);
                System.out.println("**SU TURNO**");
                try {
                    synchronized (this){
                        wait();
                    }
                } catch (InterruptedException ee) {
                    ee.printStackTrace();
                }
                
                // simulando abandono
                if (false) {
                    AbandonoEvent evento = new AbandonoEvent(jugadorThis, turno);
                    oos.writeObject(evento);
                    System.exit(0);
                } else {
                    // si no se abandonó:
                    oos.writeObject(plevent);
                    if(!plevent.pintoCuadro()){
                        turnoRotando = ++turnoRotando >= jugadores.size() ? 0 : turnoRotando;
                    }
                }


            }

        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }

    }

}
