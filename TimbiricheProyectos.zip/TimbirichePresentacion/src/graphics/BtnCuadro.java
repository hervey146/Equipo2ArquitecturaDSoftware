package graphics;

import javax.swing.JButton;
import model.Cuadro;

public class BtnCuadro extends JButton {
    private int fila;
    private int columna;
    private Cuadro cuadro;

    public BtnCuadro(int fila, int columna) {
        super();
        this.fila = fila;
        this.columna = columna;
//
//        this.setBackground(Color.white);
//        this.setSize(dimension);
//        this.setPreferredSize(dimension);
//        this.setMaximumSize(dimension);
//        this.setMargin(new Insets(0, 0, 0, 0));
//        this.setFocusPainted(false);
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }
    
    

    public Cuadro getCuadro() {
        return cuadro;
    }

    public void setCuadro(Cuadro cuadro) {
        this.cuadro = cuadro;
//        this.cuadro.getJugador().getColor();
//        this.setBackground(this.cuadro.getJugador().getColor());
//        this.setText(this.cuadro.getJugador().getLetra() + "");
    }

    
    
}
