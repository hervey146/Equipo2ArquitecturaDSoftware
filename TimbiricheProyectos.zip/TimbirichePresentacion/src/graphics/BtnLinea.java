package graphics;

import javax.swing.JButton;
import model.Linea;

public class BtnLinea extends JButton {
    private int fila;
    private int columna;
    private int orientacion;
    private Linea linea;

    public BtnLinea(int fila, int columna, int orientacion) {
        super();
        this.fila = fila;
        this.columna = columna;
        this.orientacion = orientacion;
//        this.setMargin(new Insets(0, 0, 0, 0));
//        this.setSize(dimension);
//        this.setPreferredSize(dimension);
//        this.setMaximumSize(dimension);
    }

    public Linea getLinea() {
        return linea;
    }

    public void setLinea(Linea linea) {
        this.linea = linea;
    }
    
    
    
//    public void colorearLinea(Jugador jugador){
//        this.linea.setJugador(jugador);
//        this.setBackground(jugador.getColor());
//    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public int getOrientacion() {
        return orientacion;
    }

    public void setOrientacion(int orientacion) {
        this.orientacion = orientacion;
    }

    
}
