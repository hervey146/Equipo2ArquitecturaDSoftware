package model;

public class Constantes {
    
    public static final int lineSize = 8;
    public static final int squareSize = 32;
    
    public static final int HORIZONTAL = 1;
    public static final int VERTICAL = 2;
    
    
    
}
