package eventos;

public class JugadorRepetidoEvent extends Evento{

}
