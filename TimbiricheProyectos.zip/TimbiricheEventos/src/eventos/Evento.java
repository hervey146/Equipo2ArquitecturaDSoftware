package eventos;

import java.io.Serializable;

public abstract class Evento implements Serializable {

}
