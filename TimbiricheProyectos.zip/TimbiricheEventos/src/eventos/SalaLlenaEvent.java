package eventos;

public class SalaLlenaEvent extends Evento{

    
}
