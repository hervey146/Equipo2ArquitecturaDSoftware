package timbiricheSockets;

public class PruebaServer {

    public static void main(String[] args) {

        // se corre este main para ejecutar el servidor
        TimbiricheServer ts = new TimbiricheServer(8080);
        ts.ejecutar();

    }

}
