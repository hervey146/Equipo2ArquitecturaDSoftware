package timbiricheSockets;

import EventBus.Subscribe;
import model.Jugador;
import eventos.AbandonoEvent;
import eventos.InicioPartidaEvent;
import eventos.PintaLineaEvent;
import java.io.IOException;
import java.util.List;

public class EventHandler {

    static List<Jugador> listaJugadores;
    static List<JugadorHandler> conexiones;

    public EventHandler(List<JugadorHandler> conexiones) {
        this.conexiones = conexiones;
    }

    @Subscribe
    public static void onInicioPartidaEvent(InicioPartidaEvent ipe) {
        listaJugadores = ipe.getJugadores();
        try {
            for (JugadorHandler jh : conexiones) {
        
                // se crea un nuevo Thread con el Runnable del jugador que ingresó. 
                Thread t = new Thread(jh);

                // correr el hilo. 
                t.start();

                // se envía el DTO (evento) al jugador en esta iteración
                jh.oos.writeObject(ipe);
            }
        } catch (IOException e) {
            System.out.println("ERROR DE IO");
            e.printStackTrace();
        }
    }

    @Subscribe 
    public static void onPintaLineaEvent(PintaLineaEvent ple) {
        
        // dueño de la linea
        Jugador owner = ple.getJugador();
        try {
            for (JugadorHandler jh : conexiones) {
                // se envía a todos los demás (ignora a sí mismo)
                if(jh.getJugador().getLetra() != owner.getLetra()) {
                    jh.oos.writeObject(ple);
                }
            }
        } catch (IOException e) {
            System.out.println("ERROR DE IO");
            e.printStackTrace();
        }
        
        
    }
    
    
    @Subscribe
    public static void onAbandonoEvent(AbandonoEvent ae){
        System.out.println("Ejecutando evento de abandono en EventHandler...");
        try {
            // se elimina de la lista de conexiones
            int index = -1;
            for (int i = 0; i < conexiones.size(); i++) {
                if(conexiones.get(i).getJugador().getLetra() == ae.getJugador().getLetra()){
                    index = i;
                    break;
                }
            }
            JugadorHandler jh = conexiones.remove(index);

            // se cierran los recursos
            jh.ois.close();
            jh.oos.close();
            jh.s.close();

            // se notifica a los demás
            for (JugadorHandler jjhh : conexiones) {
                System.out.println("--Enviando evento a " + jjhh.getJugador().getNombre());
                jjhh.oos.writeObject(ae);
            }
        } catch (Exception e) {
            System.out.println("ERROR DE IO");
            e.printStackTrace();
        }
        
    }
}
