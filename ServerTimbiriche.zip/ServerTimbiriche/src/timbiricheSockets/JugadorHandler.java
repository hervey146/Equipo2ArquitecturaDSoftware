package timbiricheSockets;

import EventBus.EventBusFactory;
import eventos.AbandonoEvent;
import eventos.Evento;
import eventos.PintaLineaEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import model.Jugador;



public class JugadorHandler implements Runnable {

    private Jugador jugador;
    final ObjectInputStream ois;
    final ObjectOutputStream oos;
    static int count = 0;
    static int n;
    private int turno;
    Socket s;

    // constructor 
    public JugadorHandler(Socket s, Jugador jugador, ObjectInputStream dis, ObjectOutputStream dos) {
        this.ois = dis;
        this.oos = dos;
        this.jugador = jugador;
        this.s = s;
        n = ++count;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }

    public int getTurno() {
        return turno;
    }

    public Jugador getJugador() {
        return jugador;
    }

    /**
     * Este método no se inicia hasta que se envía el evento IniciarPartida
     */
    @Override
    public void run() {

        Evento recibido;

        // inicio de partida
        try {
            System.out.println("JUGADOR " + jugador.getNombre() + " CONECTADO Y LISTO");
            while (true) {
                recibido = (Evento) ois.readObject();
                if (recibido instanceof PintaLineaEvent) {
                    EventBusFactory.getDefault().post((PintaLineaEvent) recibido);
                    System.out.println("Evento pintarLinea");
                } else if (recibido instanceof AbandonoEvent){
                    EventBusFactory.getDefault().post((AbandonoEvent) recibido);
                    System.out.println("Evento Abandono en JugadorHandler");
                }
            }
        } catch (IOException|ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            // cerrando los recursos 
            this.ois.close();
            this.oos.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
