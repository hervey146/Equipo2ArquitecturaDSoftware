package timbiricheSockets;

import EventBus.EventBusFactory;
import model.Jugador;
import eventos.InicioPartidaEvent;
import eventos.JugadorRepetidoEvent;
import eventos.SalaLlenaEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

public class TimbiricheServer {

    static List<Jugador> listaJugadores;
    static List<JugadorHandler> conexiones;
    private EventHandler eventHandler;
    private int puerto;
    // cantidad de clientes conectados
    static int cantidadJugadores = 0;

    public TimbiricheServer(int puerto) {
        listaJugadores = new ArrayList<>();
        conexiones = new Vector<>();

        // se crea el manejador de eventos con los mismos JugadorHandler
        eventHandler = new EventHandler(conexiones);
        // se registra al manejador de eventos en el event bus
        EventBusFactory.getDefault().register(eventHandler);

        this.puerto = puerto;
    }

    public void ejecutar() {

        try {
            // server is listening on the especified port
            ServerSocket ss = new ServerSocket(puerto);
            Socket s;
            System.out.println("Listo para escuchar");

            // se escucharán peticiones de clientes hasta que lleguen a 4
            while (cantidadJugadores < 4) {

                System.out.println("Esperando a un nuevo Jugador... ");

                s = ss.accept();

                System.out.println("Nuevo cliente conectado: " + s);

                // input y output streams del cliente
                ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                oos.flush();
                ObjectInputStream ois = new ObjectInputStream(s.getInputStream());

                // se lee el jugador del cliente
                Jugador j = (Jugador) ois.readObject();

                boolean existe
                        = 0 != conexiones.stream().filter((c) -> (j.getLetra() == c.getJugador().getLetra())).count();
                if (existe) {
                    // se envía el evento de jugador repetido
                    oos.writeObject(new JugadorRepetidoEvent());
                    s.close();
                } else {
                    // Se crea un manejador del jugador para esta solicitud 
                    JugadorHandler jh = new JugadorHandler(s, j, ois, oos);

                    // se añade al jugador handler a la lista de JHs
                    conexiones.add(jh);

                    // se aumenta la cantidad de jugadores en 1
                    cantidadJugadores++;
                    System.out.println("Cantidad de jugadores en lista: " + cantidadJugadores);
                }
            }
            // se revuelve la lista
            Collections.shuffle(conexiones);
            // para cada conexión, se establece el turno según la posición en la lista
            for (int i = 0; i < conexiones.size(); i++) {
                conexiones.get(i).setTurno(i);
                // se añade a la lista de jugadores para enviar el evento
                listaJugadores.add(conexiones.get(i).getJugador());
            }

            // post del evento InicioPartidaEvent 
            EventBusFactory.getDefault().post(new InicioPartidaEvent(listaJugadores));

            // ciclo para rechazar futuras solicitudes
            while (true) {
                System.out.println("YA NO SE ACEPTARÁN USUARIOS...");
                s = ss.accept();

                // input y output streams del cliente
                ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                oos.flush();
                ObjectInputStream ois = new ObjectInputStream(s.getInputStream());

                // se ignora el jugador leído
                ois.readObject();

                // se envía el evento de sala llena
                oos.writeObject(new SalaLlenaEvent());

                // se cierra el recurso
                s.close();
            }

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("ERROR DE IO");
            e.printStackTrace();
        }

    }

}
